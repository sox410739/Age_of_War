package ce1002.Final.s107502533.controller;

public class easycontroller extends mazecontroller {
	
}
