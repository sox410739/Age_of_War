package ce1002.Final.s107502533.controller;

import ce1002.Final.s107502533.Final;
import javafx.fxml.FXML;
import javafx.scene.Cursor;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class wincontroller {
	@FXML
	ImageView _exit, _stream2;
	MediaPlayer enter = new MediaPlayer(new Media(getClass().getResource("resource/enter.mp3").toString()));
	
	public void onExitClicked(MouseEvent e) {
		Final.mainStage.close();
	}
	
	public void onExitEntered(MouseEvent e) {
		enter.stop();
		enter.play();
		_exit.setLayoutX(_exit.getLayoutX() - 3);
		_exit.setLayoutY(_exit.getLayoutY() - 3);
		Final.mainScene.setCursor(Cursor.HAND);
		_stream2.setVisible(true);
	}
	
	public void onExitExit(MouseEvent e) {
		_exit.setLayoutX(_exit.getLayoutX() + 3);
		_exit.setLayoutY(_exit.getLayoutY() + 3);
		Final.mainScene.setCursor(Cursor.DEFAULT);
		_stream2.setVisible(false);
	}
}
